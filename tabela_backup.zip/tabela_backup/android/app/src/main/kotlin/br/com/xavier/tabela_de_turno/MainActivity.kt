package br.com.xavier.tabela_de_turno

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
